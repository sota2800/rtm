//このソースは、VstoneMagicによって自動生成されました。
//ソースの内容を書き換えた場合、VstoneMagicで開けなくなる場合があります。
package	jp.co.mysota;
import	main.main.GlobalVariable;
import	jp.vstone.RobotLib.*;
import	jp.vstone.sotatalk.*;
import	jp.vstone.sotatalk.SpeechRecog.*;
import	jp.vstone.network.*;
import	java.awt.Color;
import	jp.vstone.camera.*;

public class mymain
{

	public CRobotPose pose;
	public mymain()																										//@<BlockInfo>jp.vstone.block.func.constructor,32,32,160,32,False,2,@</BlockInfo>
	{
																														//@<OutputChild>
		/*CRobotPose pose*/;																							//@<BlockInfo>jp.vstone.block.variable,96,32,96,32,False,1,break@</BlockInfo>
																														//@<EndOfBlock/>
																														//@</OutputChild>
	}																													//@<EndOfBlock/>

	//@<Separate/>
	public void main()																									//@<BlockInfo>jp.vstone.block.func,64,352,1120,352,False,15,コメント@</BlockInfo>
	throws SpeechRecogAbortException {
		if(!GlobalVariable.TRUE) throw new SpeechRecogAbortException("default");

																														//@<OutputChild>
		{																												//@<BlockInfo>jp.vstone.block.tcpip.server.init,160,352,1024,352,False,14,@</BlockInfo>
			TCPIPServer tcpipServer = new TCPIPServer((short)5001,(int)5000);
			
																														//@<OutputChild>
			pose = new CRobotPose();																					//@<BlockInfo>jp.vstone.block.pose,224,352,224,352,False,13,コメント@</BlockInfo>
			pose.SetPose(	new Byte[]{1,2,3,4,5,6,7,8},
							new Short[]{0,-900,-300,900,300,0,-180,0}
							);
			pose.SetTorque(	new Byte[]{1,2,3,4,5,6,7,8},
							new Short[]{100,100,100,100,100,100,100,100}
							);
			pose.SetLed(	new Byte[]{0,1,2,8,9,10,11,12,13},
							new Short[]{0,-255,0,0,100,0,0,100,0}
							);
			GlobalVariable.motion.play(pose,1000);
			CRobotUtil.wait(1000);																						//@<EndOfBlock/>
			while(GlobalVariable.TRUE)																					//@<BlockInfo>jp.vstone.block.while.endless,320,352,928,352,False,12,Endless@</BlockInfo>
			{

																														//@<OutputChild>
				try{																									//@<BlockInfo>jp.vstone.block.tcpip.server,416,64,832,64,False,11,@</BlockInfo>
					GlobalVariable.recvString = tcpipServer.waitRequest();

					if(GlobalVariable.recvString==null) GlobalVariable.recvString="";
					if(GlobalVariable.recvString.contentEquals((String)"hello"))
					{
																														//@<OutputChild>
						pose = new CRobotPose();																			//@<BlockInfo>jp.vstone.block.pose,528,64,528,64,False,3,コメント@</BlockInfo>
						pose.SetPose(	new Byte[]{1,2,3,4,5,6,7,8},
										new Short[]{0,-900,0,-600,300,0,-180,0}
										);
						pose.SetTorque(	new Byte[]{1,2,3,4,5,6,7,8},
										new Short[]{100,100,100,100,100,100,100,100}
										);
						pose.SetLed(	new Byte[]{0,1,2,8,9,10,11,12,13},
										new Short[]{0,-255,0,0,100,0,0,100,0}
										);
						GlobalVariable.motion.play(pose,500);
						CRobotUtil.wait(500);																				//@<EndOfBlock/>
																																//@</OutputChild>

					}
					else if(GlobalVariable.recvString.contentEquals((String)"neutral"))
					{
																														//@<OutputChild>
						pose = new CRobotPose();																			//@<BlockInfo>jp.vstone.block.pose,528,160,528,160,False,16,コメント@</BlockInfo>
						pose.SetPose(	new Byte[]{1,2,3,4,5,6,7,8},
										new Short[]{0,-750,-600,750,600,0,-180,0}
										);
						pose.SetTorque(	new Byte[]{1,2,3,4,5,6,7,8},
										new Short[]{100,100,100,100,100,100,100,100}
										);
						pose.SetLed(	new Byte[]{0,1,2,8,9,10,11,12,13},
										new Short[]{0,-255,0,0,100,0,0,100,0}
										);
						GlobalVariable.motion.play(pose,500);
						CRobotUtil.wait(500);																				//@<EndOfBlock/>
																																//@</OutputChild>

					}
					else if(GlobalVariable.recvString.contentEquals((String)"question"))
					{
																														//@<OutputChild>
						pose = new CRobotPose();																			//@<BlockInfo>jp.vstone.block.pose,528,256,528,256,False,4,コメント@</BlockInfo>
						pose.SetPose(	new Byte[]{1,2,3,4,5,6,7,8},
										new Short[]{0,100,-300,900,300,0,-200,250}
										);
						pose.SetTorque(	new Byte[]{1,2,3,4,5,6,7,8},
										new Short[]{100,100,100,100,100,100,100,100}
										);
						pose.SetLed(	new Byte[]{0,1,2,8,9,10,11,12,13},
										new Short[]{0,-255,0,0,100,0,0,100,0}
										);
						GlobalVariable.motion.play(pose,500);
						CRobotUtil.wait(500);																				//@<EndOfBlock/>
																																//@</OutputChild>

					}
					else if(GlobalVariable.recvString.contentEquals((String)"speaking"))
					{
																														//@<OutputChild>
						for(int i=0;i<(int)10;i++)																			//@<BlockInfo>jp.vstone.block.for,528,352,720,352,False,7,コメント@</BlockInfo>
						{
																															//@<OutputChild>
							pose = new CRobotPose();																		//@<BlockInfo>jp.vstone.block.pose,592,352,592,352,False,6,コメント@</BlockInfo>
							pose.SetPose(	new Byte[]{1,2,3,4,5,6,7,8},
											new Short[]{0,-750,-600,750,600,0,-200,0}
											);
							pose.SetTorque(	new Byte[]{1,2,3,4,5,6,7,8},
											new Short[]{100,100,100,100,100,100,100,100}
											);
							pose.SetLed(	new Byte[]{0,1,2,8,9,10,11,12,13},
											new Short[]{0,-255,0,0,0,0,0,0,0}
											);
							GlobalVariable.motion.play(pose,500);
							CRobotUtil.wait(500);																			//@<EndOfBlock/>
							pose = new CRobotPose();																		//@<BlockInfo>jp.vstone.block.pose,656,352,656,352,False,5,コメント@</BlockInfo>
							pose.SetPose(	new Byte[]{1,2,3,4,5,6,7,8},
											new Short[]{0,-750,-600,750,600,0,-200,0}
											);
							pose.SetTorque(	new Byte[]{1,2,3,4,5,6,7,8},
											new Short[]{100,100,100,100,100,100,100,100}
											);
							pose.SetLed(	new Byte[]{0,1,2,8,9,10,11,12,13},
											new Short[]{0,-255,0,0,255,0,0,255,0}
											);
							GlobalVariable.motion.play(pose,500);
							CRobotUtil.wait(500);																			//@<EndOfBlock/>
																															//@</OutputChild>
						}																									//@<EndOfBlock/>
																																//@</OutputChild>

					}
					else if(GlobalVariable.recvString.contentEquals((String)"listening"))
					{
																														//@<OutputChild>
						for(int i=0;i<(int)5;i++)																			//@<BlockInfo>jp.vstone.block.for,528,448,720,448,False,10,コメント@</BlockInfo>
						{
																															//@<OutputChild>
							pose = new CRobotPose();																		//@<BlockInfo>jp.vstone.block.pose,592,448,592,448,False,9,コメント@</BlockInfo>
							pose.SetPose(	new Byte[]{1,2,3,4,5,6,7,8},
											new Short[]{0,-900,0,-100,300,0,-50,0}
											);
							pose.SetTorque(	new Byte[]{1,2,3,4,5,6,7,8},
											new Short[]{100,100,100,100,100,100,100,100}
											);
							pose.SetLed(	new Byte[]{0,1,2,8,9,10,11,12,13},
											new Short[]{0,-255,0,0,100,0,0,100,0}
											);
							GlobalVariable.motion.play(pose,500);
							CRobotUtil.wait(500);																			//@<EndOfBlock/>
							pose = new CRobotPose();																		//@<BlockInfo>jp.vstone.block.pose,656,448,656,448,False,8,コメント@</BlockInfo>
							pose.SetPose(	new Byte[]{1,2,3,4,5,6,7,8},
											new Short[]{0,-900,0,-100,300,0,-250,0}
											);
							pose.SetTorque(	new Byte[]{1,2,3,4,5,6,7,8},
											new Short[]{100,100,100,100,100,100,100,100}
											);
							pose.SetLed(	new Byte[]{0,1,2,8,9,10,11,12,13},
											new Short[]{0,-255,0,255,0,0,255,0,0}
											);
							GlobalVariable.motion.play(pose,500);
							CRobotUtil.wait(500);																			//@<EndOfBlock/>
																															//@</OutputChild>
						}																									//@<EndOfBlock/>
																																//@</OutputChild>

					}
					else
					{
																														//@<OutputChild>
																														//@</OutputChild>

					}
					
				} catch(Exception e) { }
																														//@<EndOfBlock/>
																														//@</OutputChild>
			}
																														//@<EndOfBlock/>
																														//@</OutputChild>

			
		}
																														//@<EndOfBlock/>
																														//@</OutputChild>

	}																													//@<EndOfBlock/>

}
